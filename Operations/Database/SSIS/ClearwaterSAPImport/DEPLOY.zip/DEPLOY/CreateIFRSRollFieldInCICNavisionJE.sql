USE ClearwaterSAP;
ALTER TABLE dbo.CICNavisionJE
ADD IFRSRoll varchar(20) NULL;
