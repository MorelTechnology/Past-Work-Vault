USE ClearwaterSAP;
ALTER TABLE dbo.AccountTranslation
ADD IFRSRoll varchar(20) NULL;
